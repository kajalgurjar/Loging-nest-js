import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AdminModule } from './module/admin/admin.module';
import typeOrmConfig from './module/admin/typeorm.config';


@Module({
    imports: [
        TypeOrmModule.forRoot(typeOrmConfig),
        AdminModule,
    ],
})
export class AppModule {}
