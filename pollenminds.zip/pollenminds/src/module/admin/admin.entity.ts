// admin.entity.ts

import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('admins')
export class Admin {

    @PrimaryGeneratedColumn({ name: 'admin_id' })
    id: number;

    @Column({ name: 'admin_name' })
    name : string;


    @Column({ name: 'admin_email' })
    email: string;

    @Column({ name: 'admin_password' })
    password: string;
}
