import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Admin } from './admin.entity';
import * as bcrypt from 'bcrypt';


@Injectable()
export class AdminService {
    private readonly logger = new Logger(AdminService.name);

    constructor(
        @InjectRepository(Admin)
        private adminRepository: Repository<Admin>,
    ) {}

    async findByEmailAndPassword(email: string, password: string): Promise<Admin> {

        const admin = await this.adminRepository.findOne({ where: { email } });
        
        if (!admin) {
            return; // Admin not found
        }

        const isPasswordValid = await bcrypt.compare(password, admin.password);
        return isPasswordValid ? admin : null;    
    }

    async createAdmin(email: string, password: string): Promise<Admin> {
        const admin = new Admin();
        admin.email = email;
        admin.password = password;
        
        // Log the password
        this.logger.log(`Password: ${password}`);
        console.log()
        return await this.adminRepository.save(admin);
    }

    async getAllAdmins(): Promise<Admin[]> {
        return await this.adminRepository.find();
    }
}
