import { Controller, Post, Body } from '@nestjs/common';
import { AdminService } from './admin.service';

@Controller('admin')
export class AdminController {
    constructor(private readonly adminService: AdminService) {}
    @Post('login')
    async login(@Body('email') email: string, @Body('password') password: string): Promise<any> 
    {
        
        const admin = await this.adminService.findByEmailAndPassword(email, password);
        
        if (admin) {
            // Admin found, return success response
            return { success: true, message: 'Login successful' };
        } else {
            // Admin not found, return error response
            return { success: false, message: 'Invalid email or password' };
        }
        
    }
}
